import React, { Component } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

/*Componentes para rutas */
import Login from './Login';
import Employees from './Employees';
import Upload from './Upload';
import Error from './Error';

class Router extends Component {
    render() {
        return (
            <BrowserRouter>
            {/*Configura rutas y páginas */}
                <Routes>
                    <Route exact path="/" element={<Login />} />
                    <Route exact path="/login" element={<Login />} />
                    <Route exact path="/employees" element={<Employees />} />
                    <Route exact path="/upload" element={<Upload />} />
                    <Route path="*" element={<Error />}/>
                </Routes>
            </BrowserRouter>
        );
    }
}

export default Router;