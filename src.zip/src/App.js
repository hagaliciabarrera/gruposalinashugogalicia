
import './App.css';
import Router from './Router';
import Login from './Login';
import { createStore, combineReducers } from 'redux';

function App() {
  return (
    <div className="App">      
      <Router />
    </div>
  );
}

export default App;
