import React from 'react';

const Error = () => {
    return (
        <div>
            <h2>Componente Error</h2>
        </div>
    );
}

export default Error;