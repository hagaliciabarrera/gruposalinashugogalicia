import React, { Component } from 'react';


class Login extends Component {
    render() {
        return (
            <div>
                <h2>Componente Login</h2>
                <input type="text" onPaste={(e) => {
                    e.preventDefault()
                    return false;
                }} onCopy={(e) => {
                    e.preventDefault()
                    return false;
                }} placeholder="Usuario" />
                <input type="password" onPaste={(e) => {
                    e.preventDefault()
                    return false;
                }} onCopy={(e) => {
                    e.preventDefault()
                    return false;
                }} placeholder="Password" />
                <input type="submit"/>
            </div>
        );
    }
}

export default Login;